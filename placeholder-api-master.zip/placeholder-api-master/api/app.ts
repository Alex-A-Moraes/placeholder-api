import express from 'express';
import bodyParser from 'body-parser';
import helmet from 'helmet';
import cors from 'cors';
import morgan from 'morgan';
import { ServiceBroker } from 'moleculer';
import ApiService from './src/api.service';

let broker = new ServiceBroker({
    nodeID: process.env.NAMESPACE || '',
    transporter: 'redis://redis',
    metrics: true,
    serializer: 'JSON',
});

const svc = new ApiService(broker);

const app = express();
app.use(helmet());
app.use(bodyParser.urlencoded());
app.use(bodyParser.json());
app.options('*', cors());
app.use(morgan(':date[iso] :method :url :status :response-time ms - :res[content-length]'));
app.use('/', svc.express());

app.route('/status').get((_req, res) => {
    res.json({
        success: true,
        serverStatus: 'OK',
        port: 3001,
    });
});

app.listen(3001, (err: any) => {
    if (err) return console.error(err);
    console.log('Open http://localhost:3001');
});

broker.start();
