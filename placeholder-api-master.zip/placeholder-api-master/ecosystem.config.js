module.exports = {
    apps: [
        {
            name: 'app',
            script: './dist/server.js',
            instances: 1,
            autorestart: true,
            error_file: './log/err.log',
            out_file: './log/out.log',
            PORT: 3001,
            URL_PLACEHOLDER: 'https://jsonplaceholder.typicode.com',
            HOST: 'localhost',
            USER: 'root',
            PASSWORD: 'root',
            DB: 'my_db',
        },
    ],
};
