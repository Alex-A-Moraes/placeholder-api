import { ServiceBroker } from 'moleculer';

const broker = new ServiceBroker({
    nodeID: 'node-1',
    transporter: 'redis://redis',
    metrics: true,
});

const service = broker.createService(TestService);
broker.start();
