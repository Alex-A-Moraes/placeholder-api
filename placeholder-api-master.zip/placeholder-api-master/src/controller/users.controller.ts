import client from '../util/client';

class UsersController {
    async getAll() {
        try {
            return client.get(`${process.env.URL_PLACEHOLDER}/users`);
        } catch (error) {
            throw error;
        }
    }
}

export default new UsersController();
