import UsersController from '../controller/users.controller';
import { Request, Response } from 'express';
import * as httpStatus from 'http-status';

const sendResponse = (res: any, statusCode: any, data: any) => {
    res.status(statusCode).json(data);
};

class UsersRoute {
    async getAll(_req: Request, res: Response) {
        UsersController.getAll()
            .then((crushs) => sendResponse(res, httpStatus.OK, crushs))
            .catch((err) => sendResponse(res, 500, err));
    }
}

export default new UsersRoute();
