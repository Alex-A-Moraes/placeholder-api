import * as mysql from 'mysql';

class DataBase {
    private DB_CONNECTION: any;
    private connection: mysql.Connection;

    constructor() {
        this.connection = mysql.createConnection({
            host: process.env.HOST,
            user: process.env.USER,
            password: process.env.PASSWORD,
            database: process.env.DB,
        });
    }

    createConnection() {
        this.connection.connect();
        this.logger();
    }

    closeConnection(message, callback) {
        this.DB_CONNECTION.close(() => {
            console.log('Mysql foi desconectado pelo: ' + message);
            callback();
        });
    }

    logger() {
        this.DB_CONNECTION = this.connection;
        this.DB_CONNECTION.on('connected', () =>
            console.log('Mysql está conectado ao ' + this.connection.config.database),
        );
        this.DB_CONNECTION.on('error', (error) =>
            console.error.bind(console, 'Erro na conexão: ' + error),
        );
        this.DB_CONNECTION.on('disconnected', () =>
            console.log('Mysql está desconectado do ' + this.connection.config.database),
        );
    }

    query(comm: any, args: any = []) {
        if (args?.length > 0) {
            return this.connection.query(comm, args);
        } else {
            return this.connection.query(comm);
        }
    }
}

export default DataBase;
